@extends('layout')

@section('content')
hi
@endsection